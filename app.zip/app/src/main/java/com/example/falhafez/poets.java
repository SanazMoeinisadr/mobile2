package com.example.falhafez;

public class poets {

    private String name;
    private String birthYearInLHijri;
    private  String deathYearInLHijri;
    private  String birthPlace;





    public String getName() {
        return name;
    }



    public String getBirthYearInLHijri() {
        return birthYearInLHijri;
    }

    public void setBirthYearInLHijri(String birthYearInLHijri) {
        this.birthYearInLHijri = birthYearInLHijri;
    }

    public String getDeathYearInLHijri() {
        return deathYearInLHijri;
    }

    public void setDeathYearInLHijri(String deathYearInLHijri) {
        this.deathYearInLHijri = deathYearInLHijri;
    }

    public String getBirthPlace() {
        return birthPlace;
    }

    public void setBirthPlace(String birthPlace) {
        this.birthPlace = birthPlace;
    }
}
